export interface Track {
    trackId: number;
    title: string;
    number: number;
    video: string;
    lyrics: string;
}
